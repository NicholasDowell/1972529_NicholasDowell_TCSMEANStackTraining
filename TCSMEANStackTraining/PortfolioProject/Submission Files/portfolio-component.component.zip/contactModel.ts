export class Contact{
    constructor(public cname:string, public phone:string){

    }
}